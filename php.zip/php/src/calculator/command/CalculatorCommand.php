<?php
namespace src\calculator\command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputDefinition;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Input\InputArgument;

class CalculatorCommand extends command
{   
    protected static $defaultName = 'calculator';
    
    protected function configure()
    {
        $this
        ->addArgument('operation',InputArgument::REQUIRED)
        ->addArgument('argument1',InputArgument::REQUIRED)
        ->addArgument('argument2',InputArgument::REQUIRED)
        ;
    }
    
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        
        $argument1 = $input->getArgument('argument1');
        $argument2= $input->getArgument('argument2');
        $operation= $input->getArgument('operation');
        
        if($operation=='add' || $operation=='addition'|| $operation=='+'|| $operation=='sum' )
        {
            $result = $argument1 + $argument2;
            $output->writeln($result);
        }
        else if($operation=='sub' || $operation=='substraction' || $operation=='-' || $operation=='diff')
        {
            $result=$argument1 - $argument2;
            $output->writeln($result);
        }
        else if($operation=='multiply' || $operation=='product' || $operation=='*')
        {
            $result = $argument1 * $argument2;
            $output->writeln($result);
        }
        else if($operation=='division' || $operation=='/')
        {
            if($argument2!=0) 
            {                
                $result=$argument1 / $argument2;
                $output->writeln($result);
            }
            else
             {
                $output->writeln("Error");
             }
        }
        else
        $output->writeln("invalid operator");
        
    }
}