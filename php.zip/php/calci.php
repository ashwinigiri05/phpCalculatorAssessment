<?php

require_once __DIR__ . '/vendor/autoload.php';

use src\calculator\command\CalculatorCommand;
use Symfony\Component\Console\Application;

$application = new Application();

$application->add(new CalculatorCommand());

$application->run();



